package com.example.demo.buoi2;


import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class NhanVien {

    private String ten;

    private int tuoi;

    private float luong;


}
